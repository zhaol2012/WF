sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("anders.aif.wf.aiflog.controller.LogList", {
		onInit: function () {

		},
		getTable: function () {
			return this.byId("tApplog");
		},
		onPopinLayoutChanged: function () {
			var oTable = this.getTable();
			var oComboBox = this.byId("idPopinLayout");
			var sPopinLayout = oComboBox.getSelectedKey();
			switch (sPopinLayout) {
			case "Block":
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			case "GridLarge":
				oTable.setPopinLayout(sap.m.PopinLayout.GridLarge);
				break;
			case "GridSmall":
				oTable.setPopinLayout(sap.m.PopinLayout.GridSmall);
				break;
			default:
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			}
		},

		onSelectionFinish: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.getTable();
			var aSticky = aSelectedItems.map(function (oItem) {
				return oItem.getKey();
			});

			oTable.setSticky(aSticky);
		},

		onToggleInfoToolbar: function (oEvent) {
			var oTable = this.getTable();
			oTable.getInfoToolbar().setVisible(!oEvent.getParameter("pressed"));
		}
	});
});
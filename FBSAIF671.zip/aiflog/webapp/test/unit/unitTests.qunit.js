/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"anders/aif/wf/aiflog/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
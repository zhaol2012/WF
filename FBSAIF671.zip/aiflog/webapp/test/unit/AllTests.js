sap.ui.define([
	"anders/aif/wf/aiflog/test/unit/controller/LogList.controller"
], function () {
	"use strict";
});